﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Drawing.Drawing2D;

namespace koil_koil_koil
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Color myColor2 = ColorTranslator.FromHtml("#0f0f10");
            butColorToString.BackColor = myColor2;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Color myColor = Color.Blue;
            string htmlColor = ColorTranslator.ToHtml(myColor);
            MessageBox.Show(htmlColor);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int iBlueColor = Color.Blue.ToArgb();
            Color myColor = Color.FromArgb(0x7800FF00);

        }

        private void button4_Click(object sender, EventArgs e)
        {

                Bitmap bm = new Bitmap(pictureBox1.Image);
                pictureBox1.Image = bm;
                for (int i = 0; i < 400; i++)
                {
                    bm.SetPixel(i, i, Color.White);
                }
                pictureBox1.Update();
            }

        private void button5_Click(object sender, EventArgs e)
        {
            Graphics g = CreateGraphics();
            for (int i = 0; i < 100; i += 5)
                g.FillRectangle(new SolidBrush(Color.White), i, 10, 1, 1);
            g.Dispose();
        }

        private Bitmap myBitmap;
        [DllImport("user32.dll", EntryPoint = "GetDC")]
        public static extern IntPtr GetDC(IntPtr hWnd);
        [DllImport("user32.dll", EntryPoint = "GetDesktopWindow")]
        public static extern IntPtr GetDesktopWindow();
        [DllImport("gdi32.dll", EntryPoint = "CreateCompatibleDC")]
        public static extern IntPtr CreateCompatibleDC(IntPtr hdc);

        [DllImport("user32.dll", EntryPoint = "GetSystemMetrics")]
        public static extern int GetSystemMetrics(int nIndex);
        [DllImport("gdi32.dll", EntryPoint = "CreateCompatibleBitmap")]
        public static extern IntPtr CreateCompatibleBitmap(IntPtr hdc,
        int nWidth, int nHeight);
        [DllImport("gdi32.dll", EntryPoint = "SelectObject")]
        public static extern IntPtr SelectObject(IntPtr hdc, IntPtr hgdiobjBmp);
        [DllImport("gdi32.dll", EntryPoint = "BitBlt")]
        public static extern bool BitBlt(IntPtr hdcDest, int nXDest,
        int nYDest, int nWidth, int nHeight, IntPtr hdcSrc,
        int nXSrc, int nYSrc, int dwRop);
        [DllImport("gdi32.dll", EntryPoint = "DeleteDC")]
        public static extern IntPtr DeleteDC(IntPtr hdc);
        [DllImport("user32.dll", EntryPoint = "ReleaseDC")]
        public static extern IntPtr ReleaseDC(IntPtr hWnd, IntPtr hDC);
        [DllImport("gdi32.dll", EntryPoint = "DeleteObject")]
        public static extern IntPtr DeleteObject(IntPtr hObject);

        public static Bitmap GetScreenColor()
        {
            int screenX;
            int screenY;
            IntPtr hBmp;
            IntPtr hdcScreen = GetDC(GetDesktopWindow());
            IntPtr hdcCompatible = CreateCompatibleDC(hdcScreen);
            screenX = GetSystemMetrics(0);
            screenY = GetSystemMetrics(1);
            hBmp = CreateCompatibleBitmap(hdcScreen, screenX, screenY);
            if (hBmp != IntPtr.Zero)
            {
                IntPtr hOldBmp = (IntPtr)SelectObject(hdcCompatible, hBmp);
                BitBlt(hdcCompatible, 0, 0, screenX, screenY,
                hdcScreen, 0, 0, 13369376);
            SelectObject(hdcCompatible, hOldBmp);
                DeleteDC(hdcCompatible);
                ReleaseDC(GetDesktopWindow(), hdcScreen);
                Bitmap bmp = System.Drawing.Image.FromHbitmap(hBmp);
                DeleteObject(hBmp);
                GC.Collect();
                return bmp;
            }
            return null;
        }
        private void label1_MouseDown(object sender, MouseEventArgs e)
        {
            myBitmap = GetDesktop();
        }

        private Bitmap GetDesktop()
        {
            throw new NotImplementedException();
        }

        private void label1_MouseUp(object sender, MouseEventArgs e)
        {
            Color myColor = myBitmap.GetPixel(MousePosition.X, MousePosition.Y);
            label1.BackColor = myColor;
        }

        public void DrawRoundedRectangle(Graphics g, Pen p, float X, float Y,
 float width, float height, float radius)
        {
            GraphicsPath gp = new GraphicsPath();
            gp.AddLine(X + radius, Y, X + width - (radius * 2), Y);
            gp.AddArc(X + width - (radius * 2), Y, radius * 2,
            radius * 2, 270, 90);
            gp.AddLine(X + width, Y + radius, X + width,
            Y + height - (radius * 2));
            gp.AddArc(X + width - (radius * 2), Y + height - (radius * 2),
            radius * 2, radius * 2, 0, 90);
            gp.AddLine(X + width - (radius * 2), Y + height, X + radius,
            Y + height);
            gp.AddArc(X, Y + height - (radius * 2), radius * 2,
            radius * 2, 90, 90);
            gp.AddLine(X, Y + height - (radius * 2), X, Y + radius);
            gp.AddArc(X, Y, radius * 2, radius * 2, 180, 90);
            gp.CloseFigure();
            g.DrawPath(p, gp);
            gp.Dispose();
        }
        private void button6_Click(object sender, EventArgs e)
        {
            DrawRoundedRectangle(CreateGraphics(), new Pen(Color.Red),
            20, 20, 200, 200, 30);
        }

    }
    }
