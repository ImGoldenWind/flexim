﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace koil_koil_koil
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        string firstNameValue;
        [EditorBrowsableAttribute(EditorBrowsableState.Never)]
        public string FirstName
        {
            get
            {
                return firstNameValue;
            }
            set
            {
                firstNameValue = value;
            }
        }
        [BrowsableAttribute(false)]
        public event EventHandler FirstNameChanged;

        public class MyUserControl : UserControl
        {

            public enum NetLanguage { CSharp, VisualBasic, ManagedCPP };
            NetLanguage myProperty;
            public NetLanguage MyProperty
            {
                get
                {
                    return myProperty;
                }
 set
                {
                    myProperty = value;
                }
            }
        }

        int min = 0; // Minimum value for progress range
        int max = 100; // Maximum value for progress range
        int val = 0; // Current progress
        Color BarColor = Color.Blue; // Color of progress meter
        protected override void OnResize(EventArgs e)
        {
            // Invalidate the control to get a repaint.
            this.Invalidate();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            SolidBrush brush = new SolidBrush(BarColor);
            float percent = (float)(val - min) / (float)(max - min);
            Rectangle rect = this.ClientRectangle;
            // Вычислим район, в котором рисуем индикатор.
            rect.Width = (int)((float)rect.Width * percent);
            // Нарисуем индикатор.
            g.FillRectangle(brush, rect);
            // Нарисуем 3D-рамку вокруг индикатора.
            Draw3DBorder(g);
            // Освободим ресурсы.
            brush.Dispose();
            g.Dispose();
        }
        public int Minimum
        {
            get
            {
                return min;
            }

 set
            {
                // Запретим отрицательные значения.
                if (value < 0)
                {
                    min = 0;
                }

                // Убедимся, что минимум никогда не устанавливается большим,
                // чем максимум.
                if (value > max)
                {
                    min = value;
                    min = value;
                }

                // Проверим, что значение все еще внутри допустимого диапозона.
                if (val < min)
                {
                    val = min;
                }
                // Запросим перерисовку элемента.
                this.Invalidate();
            }
        }
        public int Maximum
        {
            get
            {
                return max;
            }
            set
            {
                // Убедимся, что максимум не устанавливается меньше минимума.
                if (value < min)
                {
                    min = value;
                }
            max = value;
                // Убедимся, что значение остается в допустимом интервале.
                if (val > max)
                {
                    val = max;
                }
                // Запросим перерисовку элемента.
                this.Invalidate();
            }
        }
        public int Value
        {
            get
            {
                return val;
            }
            set
            {
                int oldValue = val;
                // Убедимся, что значение в допустимом интервале.
                if (value < min)
                {
                    val = min;
                }
                else if (value > max)
                {
                    val = max;
                }
                else
                {
                    val = value;
                }
                // Запросим перерисовку только измененной области.
                float percent;
                Rectangle newValueRect = this.ClientRectangle;
                Rectangle oldValueRect = this.ClientRectangle;
            // Используем новое значение, чтобы получить новый прямоугольник.
 percent = (float)(val - min) / (float)(max - min);
                newValueRect.Width = (int)((float)newValueRect.Width * percent);
                // Используем старое значение, чтобы получить
                // старый прямоугольник.
                percent = (float)(oldValue - min) / (float)(max - min);
                oldValueRect.Width = (int)((float)oldValueRect.Width * percent);
                Rectangle updateRect = new Rectangle();

                // Найдем только кусок, который нужно обновить.
                if (newValueRect.Width > oldValueRect.Width)
                {
                    updateRect.X = oldValueRect.Size.Width;
                    updateRect.Width = newValueRect.Width - oldValueRect.Width;
                }
                else
                {
                    updateRect.X = newValueRect.Size.Width;
                    updateRect.Width = oldValueRect.Width - newValueRect.Width;
                }
                updateRect.Height = this.Height;
                // Обновим только пересечение.
                this.Invalidate(updateRect);
            }
        }
        public Color ProgressBarColor
        {
            get
            {
                return BarColor;
            }
            set
            {
                BarColor = value;
            // Запросим перерисовку.
 this.Invalidate();
            }
        }
        private void Draw3DBorder(Graphics g)
        {
            int PenWidth = (int)Pens.White.Width;
            g.DrawLine(Pens.DarkGray,
            new Point(this.ClientRectangle.Left, this.ClientRectangle.Top),
            new Point(this.ClientRectangle.Width - PenWidth,
            this.ClientRectangle.Top));
            g.DrawLine(Pens.DarkGray,
            new Point(this.ClientRectangle.Left, this.ClientRectangle.Top),
            new Point(this.ClientRectangle.Left,
            this.ClientRectangle.Height - PenWidth));
            g.DrawLine(Pens.White,
            new Point(this.ClientRectangle.Left,
            this.ClientRectangle.Height - PenWidth),
            new Point(this.ClientRectangle.Width - PenWidth,
            this.ClientRectangle.Height - PenWidth));
            g.DrawLine(Pens.White,
            new Point(this.ClientRectangle.Width - PenWidth,
            this.ClientRectangle.Top),
            new Point(this.ClientRectangle.Width - PenWidth,
            this.ClientRectangle.Height - PenWidth));
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            {
                if (this.smoothProgressBar1.Value > 0)
                {
                    this.smoothProgressBar1.Value--;
                    this.smoothProgressBar2.Value++;
                }
                else
                {
                    this.timer1.Enabled = false;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.smoothProgressBar1.Value = 100;
            this.smoothProgressBar2.Value = 0;
            this.timer1.Interval = 1;
            this.timer1.Enabled = true;
        }
    }
}
