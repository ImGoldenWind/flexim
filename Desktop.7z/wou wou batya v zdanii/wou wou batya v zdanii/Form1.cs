﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace wou_wou_batya_v_zdanii
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ColumnHeader columnheader;
            // Используется для создания элементов в ListView
            ListViewItem listviewitem;
            // Устанавливаем нужный вид
            listView1.View = View.Details;
            // Создаем несколько элементов, содержащих имена и фамилии
            listviewitem = new ListViewItem("Александр");
            listviewitem.SubItems.Add("Суворов");
            this.listView1.Items.Add(listviewitem);
            listviewitem = new ListViewItem("Наполеон");
            listviewitem.SubItems.Add("Бонапарт");
            this.listView1.Items.Add(listviewitem);
            listviewitem = new ListViewItem("Михаил");
            listviewitem.SubItems.Add("Кутузов");
            this.listView1.Items.Add(listviewitem);
            listviewitem = new ListViewItem("Юлий");
            listviewitem.SubItems.Add("Цезарь");
            this.listView1.Items.Add(listviewitem);
            columnheader = new ColumnHeader();
            columnheader.Text = "Имя";
            this.listView1.Columns.Add(columnheader);
            columnheader = new ColumnHeader();
            columnheader.Text = "Фамилия";
            this.listView1.Columns.Add(columnheader);
            foreach (ColumnHeader ch in this.listView1.Columns) { ch.Width = -2; }


            // Create a root node.
            TreeNode rootNode = treeView1.Nodes.Add("Коты");
            TreeNode childNode = rootNode.Nodes.Add("Барсик");
            childNode.Tag = "Барсик - большой и умный кот";
            childNode = rootNode.Nodes.Add("Рыжик");
            childNode.Tag = "Рыжик - очень любопытный кот";
            childNode = rootNode.Nodes.Add("Мурзик");
            childNode.Tag = "Мурзик - ленивый кот";
            childNode = rootNode.Nodes.Add("Пушок");
            childNode.Tag = "Пушок - белый и пушистый кот";
            // Раскрываем все узлы дерева
            rootNode.ExpandAll();

            this.button1.Focus();
        }


        private void listView1_ColumnClick(object sender, ColumnClickEventArgs e)
        {
            if (e.Column == lvwColumnSorter.SortColumn)
            {
                // Переворачиваем направление сортировки
                if (lvwColumnSorter.Order == SortOrder.Ascending)
                {
                    lvwColumnSorter.Order = SortOrder.Descending;
                }
                else
                {
                    lvwColumnSorter.Order = SortOrder.Ascending;
                }
            }
            else
            {
                lvwColumnSorter.SortColumn = e.Column;
                lvwColumnSorter.Order = SortOrder.Ascending;
            }
            this.listView1.Sort();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            listView1.Items.Clear();
            listView1.Items.Add("Алла");
            listView1.Items.Add("София");
            listView1.Items[0].UseItemStyleForSubItems = false;
            listView1.Items[0].SubItems.Add("Пугачева", Color.Pink,
            Color.Yellow, Font);
            listView1.Items[1].UseItemStyleForSubItems = false;
            listView1.Items[1].SubItems.Add("Ротару", Color.Teal,
            Color.Violet, Font);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if ((int)Microsoft.Win32.Registry.GetValue(
            @"HKEY_CURRENT_USER\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced",

 "EnableBalloonTips", 1) == 0)

            this.Text = "Not use Balloon style";

        }
        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
            if (contextMenuStrip1.SourceControl == label1)
            {
                // cmenuOpen.Text = "Label";
            }
            // else
            //  cmenuOpen.Text = "Button";
        }

        internal class lvwColumnSorter
        {
            public static int SortColumn { get; internal set; }
            public static SortOrder Order { get; internal set; }
        }

        private void contextMenuStrip1_Opening_1(object sender, CancelEventArgs e)
        {
            timer1.Interval = 5000;
            timer1.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            SendKeys.Send("{ESC}");
            timer1.Stop();

        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedTab = this.tabPage2;

        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.tabControl1.SelectedIndex = 0;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            tabControl1.Controls.Add(new TabPage("Новая вкладка"));
        }

        /* private void treeView1_MouseMove(object sender, MouseEventArgs e)
          {
              // Получим узел в текущей позиции мыши
              TreeNode theNode = this.treeView1.GetNodeAt(e.X, e.Y);
              // Установим ToolTip, только если мышь задержалась на узле
              if ((theNode != null))
   {
                  // Проверяем, что свойство tag не пустое
                  if (theNode.Tag != null)
                  {
                      // Меняем ToolTip, если мышь переместилась на другой узел
                      if (theNode.Tag.ToString() !=
                      this.toolTip1.GetToolTip(this.treeView1))
                      {
                          this.toolTip1.SetToolTip(this.treeView1,
                          theNode.Tag.ToString());
                      }
                  }
                  else
                  {
                      this.toolTip1.SetToolTip(this.treeView1, "");
                  }
              }
   else // Если указатель не над узлом, то очистим подсказку
              {
                  this.toolTip1.SetToolTip(this.treeView1, "");
              } */

        private void InsertTab(int tabNumber, ref TabControl tabControl)
        {
            int counter = tabControl.Controls.Count;
            if (tabNumber < 0 || tabNumber > counter)
            {
                tabControl.Controls.Add(new TabPage("Вкладка"));
                return;
            }
            int target = tabControl.SelectedIndex;
            // сохраняем существующие ярлычки и очищаем элементы
            Control[] c = new Control[counter];
            tabControl.Controls.CopyTo(c, 0);
            tabControl.Controls.Clear();
            // Добавляем ярлычки до вставляемого элемента
            for (int i = 0; i < target; ++i)
                tabControl.Controls.Add(c[i]);
            // Вставляем свой ярлычок
            tabControl.Controls.Add(new TabPage("Вставленная вкладка"));
            // Добавляем ярлычки после вставляемого элемента
            for (int i = target; i < counter; ++i)
                tabControl.Controls.Add(c[i]);
        }

        private void button10_Click(object sender, EventArgs e)
        {
            InsertTab(2, ref tabControl1);
        }

        private void button8_Click(object sender, EventArgs e)
        {
            tabControl1.Controls.Remove(tabControl1.SelectedTab);
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            progressBar1.Value = (int)(performanceCounter1.NextValue());
            label1.Text = "Загрузка процессора: " +
            progressBar1.Value.ToString() + "%";
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }
    }
}
    

