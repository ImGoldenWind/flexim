﻿using System.Collections;
using System.Windows.Forms;

/// <summary>
/// Этот класс реализует интерфейс IComparer.
/// </summary>
public class ListViewColumnSorter : IComparer
{
    /// <summary>
    /// Номер колонки, по которой проводится сортировка
    /// </summary>
    private int ColumnToSort;
    /// <summary>
    /// Порядок, в котором проводится сортировка (например 'Ascending')
    /// </summary>
    private SortOrder OrderOfSort;
    /// <summary>
    /// Объект, проводящий нечувствительную к регистру сортировку
    /// </summary>
    private CaseInsensitiveComparer ObjectCompare;
    /// <summary>
    /// Конструктор. Инициализирует различные элементы
    /// </summary>
    public ListViewColumnSorter()
    {
        // Инициализировать колонку значением 0
        ColumnToSort = 0;
        // Иниацилизировать порядок сортировки значением 'none'
        OrderOfSort = SortOrder.None;
        // Инициализировать объект CaseInsensitiveComparer
        ObjectCompare = new CaseInsensitiveComparer();
    }
    /// <summary>
    /// Этот метод унаследован от интерфейса IComparer. Он сравнивает
    /// два переданных ему объекта, не обращая внимания на регистр
    /// </summary>
    /// <param name="x">Первый объект для сравнения</param>
    /// <param name="y">Второй объект для сравнения</param>
    /// <returns>Результат сравнения. '0' в случае равенства,
    /// отрицательный если 'x' меньше 'y' и положительный
    /// если 'x' больше 'y'</returns>
    public int Compare(object x, object y)
    {
        int compareResult;
        ListViewItem listviewX, listviewY;

    // Преобразует объекты для сравнения в объекты ListViewItem
 listviewX = (ListViewItem)x;
        listviewY = (ListViewItem)y;
        // Сравнивает 2 значения
        compareResult = ObjectCompare.Compare(
        listviewX.SubItems[ColumnToSort].Text,
        listviewY.SubItems[ColumnToSort].Text);
        // Подсчитывает возвращаемый результат, базируясь на результате
        // сравнения
        if (OrderOfSort == SortOrder.Ascending)
        {
            // Выбрана сортировка по возрастанию, возвращаем результат
            // операции сравнения
            return compareResult;
        }
        else if (OrderOfSort == SortOrder.Descending)
        {
            // Выбрана сортировка по убыванию, возвращаем результат
            // операции сравнения со знаком минус
            return (-compareResult);
        }
        else
        {
            // Возвращаем 0, чтобы показать равенство
            return 0;
        }
    }
    /// <summary>
    /// Получает или возвращает номер колонки, к которой применять
    /// сортировку (по умолчанию 0).
    /// </summary>
    public int SortColumn
    {
        set
        {
            ColumnToSort = value;
        }
        get
        {
            return ColumnToSort;
        }
    }

 /// <summary>
 /// Устанавливает порядок сортировки (например, 'Ascending').
 /// </summary>
    public SortOrder Order
    {
        set
        {
            OrderOfSort = value;
        }
        get
        {
            return OrderOfSort;
        }
    }
}